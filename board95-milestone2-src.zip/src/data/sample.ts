// Sample data for Milestone 2.
// These shapes mirror the database tables we will create with Prisma later
// (Operator -> Companies/Users, Trip -> Trips, Vehicle -> Vehicles).

export const CITIES = ["Blantyre", "Lilongwe", "Mzuzu"] as const;
export type City = (typeof CITIES)[number];
export type TransportType = "bus" | "matola";

export type Operator = {
  id: string;
  name: string;
  kind: "bus_company" | "matola_owner";
  verified: boolean; // set by an admin in Milestone 6
  phone?: string; // only bus companies show a public phone for now
  // Buses leave from the company's official station in each city.
  stations?: Partial<Record<City, string>>;
};

export type Vehicle = { model: string; plate: string };

export type Trip = {
  id: string;
  operatorId: string;
  type: TransportType;
  origin: City;
  destination: City;
  daysFromNow: number; // keeps sample dates current. Real trips store a date.
  departureTime: string; // "HH:mm", 24-hour
  fareMWK: number;
  seatsTotal: number;
  seatsAvailable: number;
  vehicle: Vehicle;
  stage?: string; // matolas only: the stage they leave from
  pickup: { available: boolean; extraFeeMWK?: number };
};

// Matola departure stages per city.
// TODO: Lilongwe and Mzuzu names are MOCK placeholders. Replace with real ones.
export const MATOLA_STAGES: Record<City, string[]> = {
  Blantyre: ["Kameza Round About", "Shoprite", "Kandodo Corner Shop"],
  Lilongwe: ["Lilongwe Stage A", "Lilongwe Stage B", "Lilongwe Stage C"],
  Mzuzu: ["Mzuzu Stage A", "Mzuzu Stage B"],
};

// TODO: station names are MOCK placeholders. Replace with each company's real station.
export const operators: Operator[] = [
  {
    id: "o1",
    name: "Sample Express Coaches",
    kind: "bus_company",
    verified: true,
    phone: "+265 999 000 111",
    stations: {
      Blantyre: "Sample Express Blantyre Station",
      Lilongwe: "Sample Express Lilongwe Station",
      Mzuzu: "Sample Express Mzuzu Station",
    },
  },
  {
    id: "o2",
    name: "Sample Intercity Lines",
    kind: "bus_company",
    verified: false,
    phone: "+265 888 000 222",
    stations: {
      Blantyre: "Sample Intercity Blantyre Depot",
      Lilongwe: "Sample Intercity Lilongwe Depot",
      Mzuzu: "Sample Intercity Mzuzu Depot",
    },
  },
  { id: "o3", name: "J. Banda", kind: "matola_owner", verified: true },
  { id: "o4", name: "M. Phiri", kind: "matola_owner", verified: false },
  { id: "o5", name: "T. Chirwa", kind: "matola_owner", verified: true },
];

export const trips: Trip[] = [
  {
    id: "t1", operatorId: "o1", type: "bus",
    origin: "Blantyre", destination: "Lilongwe", daysFromNow: 0,
    departureTime: "05:30", fareMWK: 18000, seatsTotal: 52, seatsAvailable: 14,
    vehicle: { model: "Scania Coach", plate: "BT 1234" },
    pickup: { available: false },
  },
  {
    id: "t2", operatorId: "o1", type: "bus",
    origin: "Lilongwe", destination: "Mzuzu", daysFromNow: 1,
    departureTime: "06:30", fareMWK: 20000, seatsTotal: 52, seatsAvailable: 3,
    vehicle: { model: "Scania Coach", plate: "BT 5678" },
    pickup: { available: false },
  },
  {
    id: "t3", operatorId: "o3", type: "matola",
    origin: "Blantyre", destination: "Lilongwe", daysFromNow: 0,
    departureTime: "07:00", fareMWK: 22000, seatsTotal: 7, seatsAvailable: 2,
    vehicle: { model: "Toyota Hiace", plate: "MZ 4521" },
    stage: "Kameza Round About",
    pickup: { available: true, extraFeeMWK: 3000 },
  },
  {
    id: "t4", operatorId: "o4", type: "matola",
    origin: "Mzuzu", destination: "Lilongwe", daysFromNow: 1,
    departureTime: "08:15", fareMWK: 21000, seatsTotal: 8, seatsAvailable: 0,
    vehicle: { model: "Toyota Noah", plate: "MC 9012" },
    stage: "Mzuzu Stage A",
    pickup: { available: true, extraFeeMWK: 2500 },
  },
  {
    id: "t5", operatorId: "o2", type: "bus",
    origin: "Blantyre", destination: "Mzuzu", daysFromNow: 2,
    departureTime: "04:45", fareMWK: 35000, seatsTotal: 60, seatsAvailable: 26,
    vehicle: { model: "Yutong Coach", plate: "BT 7788" },
    pickup: { available: false },
  },
  {
    id: "t6", operatorId: "o5", type: "matola",
    origin: "Blantyre", destination: "Lilongwe", daysFromNow: 1,
    departureTime: "06:00", fareMWK: 22000, seatsTotal: 7, seatsAvailable: 5,
    vehicle: { model: "Toyota Hiace", plate: "BT 3310" },
    stage: "Shoprite",
    pickup: { available: false },
  },
  {
    id: "t7", operatorId: "o3", type: "matola",
    origin: "Blantyre", destination: "Mzuzu", daysFromNow: 2,
    departureTime: "05:00", fareMWK: 38000, seatsTotal: 7, seatsAvailable: 4,
    vehicle: { model: "Toyota Hiace", plate: "MZ 4521" },
    stage: "Kandodo Corner Shop",
    pickup: { available: true, extraFeeMWK: 4000 },
  },
  {
    id: "t8", operatorId: "o5", type: "matola",
    origin: "Lilongwe", destination: "Blantyre", daysFromNow: 0,
    departureTime: "09:30", fareMWK: 22000, seatsTotal: 8, seatsAvailable: 6,
    vehicle: { model: "Toyota Noah", plate: "LL 2045" },
    stage: "Lilongwe Stage B",
    pickup: { available: true, extraFeeMWK: 3000 },
  },
  {
    id: "t9", operatorId: "o2", type: "bus",
    origin: "Lilongwe", destination: "Blantyre", daysFromNow: 1,
    departureTime: "07:30", fareMWK: 18500, seatsTotal: 60, seatsAvailable: 31,
    vehicle: { model: "Yutong Coach", plate: "LL 6601" },
    pickup: { available: false },
  },
  {
    id: "t10", operatorId: "o1", type: "bus",
    origin: "Mzuzu", destination: "Blantyre", daysFromNow: 2,
    departureTime: "05:00", fareMWK: 35000, seatsTotal: 52, seatsAvailable: 9,
    vehicle: { model: "Scania Coach", plate: "BT 5678" },
    pickup: { available: false },
  },
];
