import {
  CITIES, operators, trips,
  type City, type Operator, type Trip, type TransportType,
} from "@/data/sample";

// A Trip joined with its operator, a real date, and where it departs from.
export type TripListing = Trip & {
  operator: Operator;
  date: string; // "YYYY-MM-DD"
  departurePoint: string;
};

// "YYYY-MM-DD" in local time (toISOString would shift the day by timezone).
export function toDateString(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function todayString(): string {
  return toDateString(new Date());
}

// Today this reads from sample data. In Milestone 3 only this function
// changes, to a Prisma query, and the pages stay the same.
export function getAllTrips(): TripListing[] {
  return trips.map((trip) => {
    const operator = operators.find((o) => o.id === trip.operatorId)!;
    const d = new Date();
    d.setDate(d.getDate() + trip.daysFromNow);

    // Buses leave from the company's official station; matolas from a stage.
    const departurePoint =
      trip.type === "bus"
        ? (operator.stations?.[trip.origin] ?? `${trip.origin} bus station`)
        : (trip.stage ?? `${trip.origin} stage`);

    return { ...trip, operator, date: toDateString(d), departurePoint };
  });
}

export type Filters = {
  origin?: City;
  destination?: City;
  date?: string;
  type?: TransportType;
};

// Query-string values are user input, so we validate every one.
// Anything unrecognised is ignored instead of crashing or leaking through.
type RawParams = Record<string, string | string[] | undefined>;

function first(v: string | string[] | undefined): string | undefined {
  return Array.isArray(v) ? v[0] : v;
}

export function parseFilters(params: RawParams): Filters {
  const origin = first(params.origin);
  const destination = first(params.destination);
  const date = first(params.date);
  const type = first(params.type);

  return {
    origin: CITIES.find((c) => c === origin),
    destination: CITIES.find((c) => c === destination),
    date: date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : undefined,
    type: type === "bus" || type === "matola" ? type : undefined,
  };
}

export function filterTrips(all: TripListing[], f: Filters): TripListing[] {
  return all
    .filter((t) => !f.origin || t.origin === f.origin)
    .filter((t) => !f.destination || t.destination === f.destination)
    .filter((t) => !f.date || t.date === f.date)
    .filter((t) => !f.type || t.type === f.type)
    .sort((a, b) =>
      `${a.date} ${a.departureTime}`.localeCompare(`${b.date} ${b.departureTime}`),
    );
}
